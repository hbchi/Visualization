#ifndef CODE_sjdbBuildIndex
#define CODE_sjdbBuildIndex

#include "Parameters.h"
#include "PackedArray.h"

void sjdbBuildIndex (Parameters *P, Parameters *P1, char *Gsj, char *G, PackedArray &SA, PackedArray &SA2, PackedArray &SAi);

#endif
