#ifndef CODE_sjdbInsertJunctions
#define CODE_sjdbInsertJunctions

#include "Parameters.h"
#include "Genome.h"
#include "SjdbClass.h"

void sjdbInsertJunctions(Parameters * P, Parameters * P1, Genome & genome, SjdbClass & sjdbLoci);

#endif
